﻿document.write("&nbsp;&nbsp;&nbsp;&nbsp;※<font color=4B4221>本站是关于古典文学<br>&nbsp;&nbsp;&nbsp;的个人网站,如果服务不<br>&nbsp;&nbsp;&nbsp;到位，请体谅.</font>");
document.write("<br>&nbsp;&nbsp;&nbsp;&nbsp;※<font color=4B4221>本站程序是网上下载<br>&nbsp;&nbsp;&nbsp;的免费源码.还不错吧.</font>");
document.write("<br>&nbsp;&nbsp;&nbsp;&nbsp;※<font color=4B4221>这套模版是我自己修<br>&nbsp;&nbsp;&nbsp;改的，自我感觉还不错.</font>");
document.write("<br>&nbsp;&nbsp;&nbsp;&nbsp;※<font color=4B4221>感谢<a href=http://www.htsky.com>海棠别苑</a>提供<br>&nbsp;&nbsp;&nbsp;技术支持.</font>");